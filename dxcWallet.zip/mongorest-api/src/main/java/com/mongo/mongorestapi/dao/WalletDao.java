package com.mongo.mongorestapi.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import com.mongo.mongorestapi.model.Wallet;


@Component
public class WalletDao {

	@Autowired
	private MongoTemplate mongoTemplate;


	public List<Wallet> getAllUsers() {
		return mongoTemplate.findAll(Wallet.class);
	}

	public Wallet getUserById(String email) {
		Query query = new Query();
		query.addCriteria(Criteria.where("email").is(email));
		return mongoTemplate.findOne(query, Wallet.class);
	}

	public Wallet saveUser(Wallet wallet) {
		mongoTemplate.save(wallet);
		return wallet;
	}

	

	
}
