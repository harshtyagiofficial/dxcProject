package com.mongo.mongorestapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mongo.mongorestapi.dao.WalletDao;
import com.mongo.mongorestapi.model.Wallet;


@CrossOrigin
@RestController
public class WalletController {

	@Autowired
	WalletDao walletdao;
	
	@PostMapping(value="dxcwallet")
	public Wallet saveUser(@RequestBody Wallet wallet)
	{
		return walletdao.saveUser(wallet);
	}
	
	@GetMapping(value="dxcwallet")
	public List<Wallet> getAllRest()
	{
		return walletdao.getAllUsers(); 
		
	}
	
	@GetMapping(value="dxcwallet/{email}")
	public Object getUser(@PathVariable String email )
	{
		return walletdao.getUserById(email); 
		
	}
	

}
