package com.mongo.mongorestapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongorestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongorestApiApplication.class, args);
	}

}
