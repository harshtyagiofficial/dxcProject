package com.mongo.mongorestapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mongo.mongorestapi.dao.WalletDao;
import com.mongo.mongorestapi.model.Wallet;

@CrossOrigin
@RestController
public class WalletController {

	@Autowired
	WalletDao walletdao;

	@PostMapping(value = "dxcwallet")
	public Wallet saveUser(@RequestBody Wallet wallet) {
		return walletdao.saveUser(wallet);
	}

	@GetMapping(value = "dxcwallet")
	public List<Wallet> getAllUser() {
		return walletdao.getAllUsers();

	}

	@GetMapping(value = "dxcwallet/{email}")
	public Object getUser(@PathVariable String email) {
		return walletdao.getUserById(email);

	}

	@DeleteMapping(value = "dxcwallet/{email}")
	public void deleteUser(@PathVariable String email) {
		walletdao.delete(email);

	}

	@PutMapping(value = "dxcwallet/{email}/{amount}")
	public void updateUser(@PathVariable String email, @PathVariable int amount) {
		walletdao.update(email, amount);

	}
	
	@PutMapping(value="dxcwallet/{email}/{shopName}/{amount}")
	public void payMoney(@PathVariable String email,@PathVariable String shopName,@PathVariable int amount)
	{
		walletdao.payMoney(email,shopName,amount);
	}

	@PutMapping(value = "dxcwallet/password/{email}/{newPassword}")
	public void updatePassword(@PathVariable String email, @PathVariable String newPassword) {
		walletdao.updatePassword(email, newPassword);
	}

	@PutMapping(value = "dxcwallet/passbook/{email}/{to}/{balance}")
	public void updatePassbook(@PathVariable String email, @PathVariable String to, @PathVariable int balance) {
		walletdao.updatePassbookDetails(email, to, balance);
	}

	@PutMapping(value = "dxcwallet/transferpassbook/{email}/{to}/{balance}")
	public void updateTransferPassbook(@PathVariable String email, @PathVariable String to, @PathVariable int balance) {
		walletdao.updateTransferPassbookDetails(email, to, balance);
	}

}
